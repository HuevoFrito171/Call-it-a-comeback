use anchor_lang::prelude::*;
use anchor_spl::token::{self, Mint, Token, TokenAccount, Transfer};

declare_id!("B8bLT9No86CxFfr3L7nr1T3Vb8wjcfViMcCSERyHqV7N"); // Playground will replace this

#[program]
pub mod call_it_a_comeback {
    use super::*;

    // Initialize the CIC token mint
    pub fn initialize_token(ctx: Context<InitializeToken>) -> Result<()> {
        let cpi_accounts = token::InitializeMint {
            mint: ctx.accounts.mint.to_account_info(),
            rent: ctx.accounts.rent.to_account_info(),
        };
        let cpi_program = ctx.accounts.token_program.to_account_info();
        let cpi_ctx = CpiContext::new(cpi_program, cpi_accounts);
        token::initialize_mint(cpi_ctx, 9, &ctx.accounts.authority.key(), None)?; // 9 decimals, authority = deployer

        // Mint 100B CIC to the authority's token account
        let cpi_accounts = token::MintTo {
            mint: ctx.accounts.mint.to_account_info(),
            to: ctx.accounts.authority_token_account.to_account_info(),
            authority: ctx.accounts.authority.to_account_info(),
        };
        let cpi_program = ctx.accounts.token_program.to_account_info();
        let cpi_ctx = CpiContext::new(cpi_program, cpi_accounts);
        token::mint_to(cpi_ctx, 100_000_000_000_000_000_000)?; // 100B CIC with 9 decimals

        Ok(())
    }

    // Initialize a voting round
    pub fn start_voting(ctx: Context<StartVoting>, week: u64) -> Result<()> {
        let voting_state = &mut ctx.accounts.voting_state;
        voting_state.week = week;
        voting_state.total_votes = 0;
        voting_state.is_active = true;
        Ok(())
    }

    // Nominate a candidate
    pub fn nominate(ctx: Context<Nominate>, nominee_key: Pubkey) -> Result<()> {
        let nominee = &mut ctx.accounts.nominee;
        nominee.votes = 0;
        nominee.nominee_key = nominee_key;
        nominee.is_winner = false;
        Ok(())
    }

    // Vote by sending CIC to a nominee's wallet
    pub fn vote(ctx: Context<Vote>, amount: u64) -> Result<()> {
        require!(ctx.accounts.voting_state.is_active, ErrorCode::VotingClosed);

        // Transfer CIC from voter to nominee's token account
        let cpi_accounts = Transfer {
            from: ctx.accounts.voter_token_account.to_account_info(),
            to: ctx.accounts.nominee_token_account.to_account_info(),
            authority: ctx.accounts.voter.to_account_info(),
        };
        let cpi_program = ctx.accounts.token_program.to_account_info();
        let cpi_ctx = CpiContext::new(cpi_program, cpi_accounts);
        token::transfer(cpi_ctx, amount)?;

        // Update vote counts
        let nominee = &mut ctx.accounts.nominee;
        nominee.votes += amount;
        ctx.accounts.voting_state.total_votes += amount;

        Ok(())
    }

    // End voting and mark winner (manual for now)
    pub fn end_voting(ctx: Context<EndVoting>) -> Result<()> {
        let voting_state = &mut ctx.accounts.voting_state;
        require!(voting_state.is_active, ErrorCode::VotingAlreadyClosed);
        voting_state.is_active = false;

        // Winner logic TBD: For now, assume manual check of nominee.votes
        let nominee = &mut ctx.accounts.nominee;
        nominee.is_winner = true; // Placeholder—needs multi-nominee comparison

        Ok(())
    }
}

// Accounts structs
#[derive(Accounts)]
pub struct InitializeToken<'info> {
    #[account(mut)]
    pub mint: Account<'info, Mint>,
    #[account(mut)]
    pub authority: Signer<'info>,
    #[account(mut)]
    pub authority_token_account: Account<'info, TokenAccount>,
    pub token_program: Program<'info, Token>,
    pub rent: Sysvar<'info, Rent>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
#[instruction(week: u64)]
pub struct StartVoting<'info> {
    #[account(
        init,
        payer = authority,
        space = 8 + 8 + 8 + 1, // Discriminator + week + total_votes + is_active
        seeds = [b"voting", week.to_le_bytes().as_ref()],
        bump
    )]
    pub voting_state: Account<'info, VotingState>,
    #[account(mut)]
    pub authority: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct Nominate<'info> {
    #[account(
        init,
        payer = nominator,
        space = 8 + 8 + 32 + 1, // Discriminator + votes + nominee_key + is_winner
        seeds = [b"nominee", nominator.key().as_ref()],
        bump
    )]
    pub nominee: Account<'info, Nominee>,
    #[account(mut)]
    pub nominator: Signer<'info>,
    pub system_program: Program<'info, System>,
}

#[derive(Accounts)]
pub struct Vote<'info> {
    #[account(mut)]
    pub voting_state: Account<'info, VotingState>,
    #[account(mut)]
    pub nominee: Account<'info, Nominee>,
    #[account(mut)]
    pub voter_token_account: Account<'info, TokenAccount>,
    #[account(mut)]
    pub nominee_token_account: Account<'info, TokenAccount>,
    #[account(mut)]
    pub voter: Signer<'info>,
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct EndVoting<'info> {
    #[account(mut)]
    pub voting_state: Account<'info, VotingState>,
    #[account(mut)]
    pub nominee: Account<'info, Nominee>, // Single nominee for now
    #[account(mut)]
    pub authority: Signer<'info>,
}

// Data structs
#[account]
pub struct VotingState {
    pub week: u64,
    pub total_votes: u64,
    pub is_active: bool,
}

#[account]
pub struct Nominee {
    pub votes: u64,
    pub nominee_key: Pubkey,
    pub is_winner: bool,
}

#[error_code]
pub enum ErrorCode {
    #[msg("Voting is closed")]
    VotingClosed,
    #[msg("Voting already closed")]
    VotingAlreadyClosed,
}